#!/tools/pdtooling/packages/VirtPythonEnv/pkg_synopsys/bin/python3
import projectinfo

try:
    print(f"{projectinfo.cmd=}")
    print(f"{projectinfo.current_version=}")
    print(f"{projectinfo.dataorg=}")
    print(f"{projectinfo.dataorg_src=}")
    print(f"{projectinfo.project=}")
    print(f"{projectinfo.version=}")
    print(f"{projectinfo.projects=}")
    print(f"{projectinfo.technology=}")
    print(f"{projectinfo.variant=}")


    print(f"Project: {projectinfo.project} Version: {projectinfo.version}")
    print(f"Project: {projectinfo.project} Version: {projectinfo.version}")
    print(f"Project: {projectinfo.project} Version: {projectinfo.version}")
    print(f"Project: {projectinfo.project} Version: {projectinfo.version}")
except Exception as e:
    print(e)
