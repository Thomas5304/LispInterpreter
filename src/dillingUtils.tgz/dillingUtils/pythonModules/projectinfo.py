"""
projectinfo.py

In-memory lazy cache fuer die beiden Befehle:
  project_info -project
  project_info -version

Zugriff:
  import projectinfocache as pi
  print(pi.project)    # fuehrt beim ersten Zugriff `project_info -project` aus
  print(pi.version)    # fuehrt beim ersten Zugriff `project_info -version` aus

Funktionen:
  clear_cache()         # leert den Cache (naechster Zugriff fuehrt Kommando erneut aus)
  refresh(name=None)    # zwingt erneute Ausfuehrung: 'project', 'version' oder None (beide)
"""

from __future__ import annotations
import subprocess
import shlex
import functools
from typing import Optional

DEFAULT_TIMEOUT = 10.0  # Sekunden fuer subprocess-Aufrufe

def _run_cmd(args, timeout: float = DEFAULT_TIMEOUT) -> str:
    """
    Fuehrt ein Kommando sicher aus (argument-list, kein shell=True), gibt stdout zurueck.
    Wirft RuntimeError bei non-zero exit oder anderen Fehlern.
    """
    # args kann List[str] oder str sein; falls str -> shlex.split
    if isinstance(args, str):
        args = shlex.split(args)

    proc = subprocess.run(args,
                          stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,
                          text=True,
                          timeout=timeout)
    if proc.returncode != 0:
        raise RuntimeError(f"Command {' '.join(args)} failed ({proc.returncode}): {proc.stderr.strip()}")
    return proc.stdout.strip()


# project_info answer in cura
#CMD                  project -Gon cura --
#CURRENT_VERSION      0101
#DATAORG              df2
#DATAORG_SRC          proot (/proot/cura/0101/control/project.ident)
#PROJECT              cura
#PROJECTS             cura
#TECHNOLOGY           c05m3
#VARIANT              ALL
#VERSION              0101

class ProjectInfoError(Exception):
    def __init__(s):
        __super__.__init__(s)

@functools.lru_cache(maxsize=1)
def _get_project() -> str:
    return _run_cmd(["project_info", "PROJECT"])

@functools.lru_cache(maxsize=1)
def _get_version() -> str:
    try:
        return _run_cmd(["project_info", "VERSION"])
    except Exception as e:
        raise ProjectInfoError("project_info error for VERSION")

@functools.lru_cache(maxsize=1)
def _get_cmd() -> str:
    return _run_cmd(["project_info", "CMD"])

@functools.lru_cache(maxsize=1)
def _get_current_version() -> str:
    return _run_cmd(["project_info", "CURRENT_VERSION"])

@functools.lru_cache(maxsize=1)
def _get_dataorg() -> str:
    return _run_cmd(["project_info", "DATAORG"])

@functools.lru_cache(maxsize=1)
def _get_dataorg_src() -> str:
    return _run_cmd(["project_info", "DATAORG_SRC"])

@functools.lru_cache(maxsize=1)
def _get_projects() -> str:
    return _run_cmd(["project_info", "PROJECTS"])

@functools.lru_cache(maxsize=1)
def _get_technology() -> str:
    return _run_cmd(["project_info", "TECHNOLOGY"])

@functools.lru_cache(maxsize=1)
def _get_variant() -> str:
    return _run_cmd(["project_info", "VARIANT"])





def clear_cache() -> None:
    """Leert den In Memory Cache (die naechsten Zugriffe rufen die Subprozesse neu auf)."""
    _get_project.cache_clear()
    _get_version.cache_clear()
    _get_cmd.cache_clear()
    _get_current_version.cache_clear()
    _get_dataorg.cache_clear()
    _get_dataorg_src.cache_clear()
    _get_projects.cache_clear()
    _get_technology.cache_clear()
    _get_variant.cache_clear()


def refresh(name: Optional[str] = None) -> str | None:
    """
    Frischt den Cache und gibt das neue Ergebnis zurueck.
    name: 'project' oder 'version' oder None (beide).
    Gibt string zurueck (bei name konkret) oder None, wenn None (beide).
    """
    if name is None:
        clear_cache()
        # entfacht beide Aufrufe, damit beim Refresh direkt ausgefuehrt wird:
        p = _get_project()
        v = _get_version()
        _get_cmd()
        _get_current_version()
        _get_dataorg()
        _get_projects()
        _get_technology()
        _get_variant()
        return None
    if name == "project":
        _get_project.cache_clear()
        return _get_project()
    if name == "version":
        _get_version.cache_clear()
        return _get_version()
    if name == "cmd":
        _get_cmd.cache_clear()
        return _get_cmd()
    if name == "current_version":
        _get_current_version.cache_clear()
        return _get_current_version()
    if name == "dataorg":
        _get_dataorg.cache_clear()
        return _get_dataorg()
    if name == "dataorg_src":
        _get_dataorg_src.cache_clear()
        return _get_dataorg_src()
    if name == "projects":
        _get_projects.cache_clear()
        return _get_projects()
    if name == "technology":
        _get_technology.cache_clear()
        return _get_technology()
    if name == "variant":
        _get_variant.cache_clear()
        return _get_variant()
    raise ValueError("name muss 'project', 'version' oder None sein")


def __getattr__(name: str):
    """
    Ermoeglicht Zugriff als Modul Attributen:
      import project_info_cache as pic
      pic.project   # lazy
      pic.version   # lazy
    """
    try:
        if name == "project":
            return _get_project()
        if name == "version":
            return _get_version()
        if name == "cmd":
            return _get_cmd()
        if name == "current_version":
            return _get_current_version()
        if name == "dataorg":
            return _get_dataorg()
        if name == "dataorg_src":
            return _get_dataorg_src()
        if name == "projects":
            return _get_projects()
        if name == "technology":
            return _get_technology()
        if name == "variant":
            return _get_variant()
    except Exception as e:
        return ""
    except RuntimeError as rte:
        return ""
    raise AttributeError(f"module {__name__} has no attribute {name}")


# Optional: explizit machen, was exportiert wird
__all__ = ["project", "version", "cmd", "current_version", "dataorg", "dataorg_src", "projects", "technology", "variant", "clear_cache", "refresh", "DEFAULT_TIMEOUT"]
