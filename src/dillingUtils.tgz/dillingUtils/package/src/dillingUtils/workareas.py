from __future__ import annotations
import functools
import os
from .projectinfo import project, version
from pathlib import Path

def generateWorkareasName(workareas="workareas-sos"):
    return Path(f"/proot/{project}/{version}/{workareas}")

def generateWorkdirName(workareas="workareas-sos", user=None):
    if user is None:
        user = os.getlogin()
    return Path(f"{generateWorkareasName(workareas)}/{user}")

def guessWorkdirName(user=None):
    if user is None:
        user = os.getlogin()
    workdirprecedence=["workareas-"+s for s in ["sos", "cd"]]
    for ws in workdirprecedence:
        wd = generateWorkdirName(workareas=ws, user = user)
        if os.path.isdir(wd):
            return wd
    raise FileNotFoundError(f"Workarea not found, tried {', '.join(workdirprecedence)} for user {user}")

def generateJobDir(topcell, jobname, user = None):
    if user is None:
        user = os.getlogin()
    if not user:
        raise RuntimeError("No user name")
    if not topcell:
        raise RuntimeError("No topcell name")
    if not jobname:
        raise RuntimeError("No job name")
    return Path(f"/prosec/{project}/{version}/{user}/{topcell}/{jobname}")
