#!/tools/pdtooling/packages/VirtPythonEnv/pkg_synopsys/bin/python3
from collections import defaultdict
from typing import Any, Protocol, Callable, Tuple
import os
import re
from pathlib import Path
import asyncio
from time import perf_counter

gdsinfopath=Path("/usr/local/lib/gdsutils/gdsinfo")
class SyntaxError(Exception):
    def __init__(self, message):
        super.__class__(message)

def set_gdsinfo_path(path:Path):
    if path.is_file():
        if os.access(path, os.X_OK):
            gdsinfopath = path
        else:
            raise PermissionError("{path} is not executable!")
    else:
        raise FileExistsError(f"'{path}' does not exist!")

def show_listed_names(names:list[str]):
    if names:
        return f"{', '.join(names)}"
    return "-None-"

class GDSIIFile_protocol(Protocol):
    _regestry:dict[str]
    def register_cell(cell):
        ...
    def cell_for_name(self, name: str):
        ...

class Cell_Definition_Protocol(Protocol):
    _called_by_cells : set[str]
    def is_topcell():
        ...
    def is_leafcell():
        ...
    def is_defined():
        ...
    def add_call(cellname:str):
        ...
    def _called_by(cellname:str):
        ...

class Celldef:

    def __init__(self, gdsfile:GDSIIFile_protocol, name: str, defined:bool=True):
        self._gdsfile : GDSIIFile_protocol = gdsfile
        self._cellname :str = name
        self._calling : defaultdict[str,int] = defaultdict(lambda:0)
        self._called_by_cells : set[str] = set()
        self._is_defined = defined
        # last action in init
        #self._gdsfile.register_cell(self)
        
    def _get_cell_from_regestry(self, cellname):
        if cellname not in self._gdsfile._regestry:
            self._gdsfile._regestry[cellname] = self.__class__(self._gdsfile, cellname, defined = False)
        return self._gdsfile._regestry[cellname]
    
    def __str__(self):
        return f"cell '{self._cellname}' {'defined' if self.is_defined() else 'undefined'}\n  - calling {show_listed_names(self._calling.keys())}\n  - called_by {show_listed_names(self._called_by_cells)}"
    
    #cell properties
    def is_topcell(self):
        return len(self._called_by_cells)==0
    
    def is_leafcell(self):
        return len(self._calling) == 0
    
    def cellname(self):
        return self._cellname
    
    # child cells
    def childcells(self):
        return self._calling.keys()
    
    def number_of_cellcalls(self, cellname:str):
        return self._calling[cellname]
    
    def is_defined(self):
        return self._is_defined
    
    def define(self):
        self._is_defined = True
    
    # parents
    def parents(self):
        return list(self._called_by_cells)
            
    def _called_by(self, cellname):
        self._called_by_cells.add(cellname)
        
    def add_call(self, cellname:str):
        #print(f"add_call of '{cellname}' to cell '{self.cellname()}'")
        self._calling[cellname] += 1
        self._get_cell_from_regestry(cellname)._called_by(self.cellname())
        return self


class GDSIIFile:
    def __init__(self, gdsii_file_name:Path, topcell:str=None):
        self._regestry : dict[str, GDSIIFile.Celldef] = dict()
        self._gdsii_file_name = gdsii_file_name
        self._topcell = topcell
        self.layerdef : defaultdict[int, set[int]] = defaultdict(lambda : set())
        
    def register_cell(self, cell:Celldef):
        if cell is None:
            return
        if cell.cellname in self._regestry:
            raise KeyError(f"Cell '{cell.cellname()} already registered!")
        self._regestry[cell.cellname()] = cell
                
    def path_to_gdsii(self):
        return self._gdsii_file_name
    
    def topcell(self):
        if self._topcell is None:
            all_topcells = self.all_topcell_names()
            if len(all_topcells) == 1:
                self._topcell = all_topcells[0]
        return self._topcell 
    
    def all_topcell_names(self) -> list[str]:
        return [n for n,c in self._regestry.items() if c.is_topcell()]
    
    def all_leafcell_names(self) -> list[str]:
        return [n for n,c in self._regestry.items() if c.is_leafcell()]
    
    def all_undefined_cell_names(self) -> list[str]:
        return [n for n,c in self._regestry.items() if not c.is_defined()]
        
    
    def all_cell_names(self):
        return self._regestry.keys()
    
    def all_cells(self):
        return self._regestry.values()
    
    def cells_for_names(self, names: list[str]):
        return [self._regestry[c] for c in names]

    def cell_for_name(self, name: str):
        return self._regestry[name]
    
    def define_cell(self, cellname:str) -> Celldef:
        if cellname not in self._regestry:
            self._regestry[cellname] = Celldef(self, cellname, True)
        cell = self._regestry[cellname]
        if not cell.is_defined():
            cell.define()
        return cell

    def call_cell(self, calling: str, called: str):
        pass
    
    def definelayer(self, layerno:int, datatype:int):
        datatypes = self.layerdef[layerno]
        datatypes.add(datatype)
    
    def get_layer(self):
        return self.layerdef.keys()
    
    def get_datatype(self, layerno:int):
        return self.layerdef[layerno]

    def get_layer_datatypes(self):
        return [(lno, dt) for lno, dtl in self.layerdef.items() for dt in dtl]
    

class GDSInfoParser:
    def __init__(self, gdsfile:GDSIIFile, gdsinfopath : Path = Path(gdsinfopath)):
        self._gdsinfopath: Path = gdsinfopath
        self._gdsfile: GDSIIFile = gdsfile
        self._actcell: Celldef = None
        
        # Regexpressions
        self.units_re = re.compile(r"Units: ([+-]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?)")
        self.celldef_re = re.compile(r"^s*Celldef:\s([^   ]+)$")
        self.cellref_re = re.compile(r"^s*Cellref:\s([^   ]+)$")
        self.layerdef_re = re.compile(r"Layer:\s(\d+)\s+Datatype:\s(\d+)")
        self.empty_line = re.compile(r"^\s*$")

    def read_gdsinfo_line(self, lineno:int, gdsinfo_line:str):
        if self.empty_line.match(gdsinfo_line):
            pass

        elif m:=self.units_re.match(gdsinfo_line):
            pass

        elif m:=self.celldef_re.match(gdsinfo_line):
            self._actcell = self._gdsfile.define_cell(m.group(1))
            
        elif m:=self.cellref_re.match(gdsinfo_line):
            if self._actcell is None:
                raise SyntaxError(f"Don't know in which cell to call cell {m.group(1)} in line {lineno}")
            self._actcell.add_call(m.group(1))

        elif m:=self.layerdef_re.match(gdsinfo_line):
            self._gdsfile.definelayer(int(m.group(1)), int(m.group(2)))

        else:
            raise SyntaxError(f"Unknown keyword in line {lineno}: {gdsinfo_line}")
        
    def read_gdsinfo_string(self, gdsinfo_output: str):
        lines = gdsinfo_output.split("\n")

        for n,line in enumerate(lines):
            self.read_gdsinfo_line(n, line)

    def read_gdsinfo(self):
        with subprocess.Popen([str(self._gdsinfopath), str(self._gdsfile.path_to_gdsii())], stdout=subprocess.PIPE, bufsize=0) as proc:
            for bline in proc.stdout:
                # bline ist bytes, evtl. decode:
                line = bline.decode("utf-8", errors="replace")
                print(line.rstrip())
    
    async def read_gdsinfo_async(self):
        proc = await asyncio.create_subprocess_exec(str(self._gdsinfopath), str(self._gdsfile.path_to_gdsii()), stdout=asyncio.subprocess.PIPE, stderr= asyncio.subprocess.PIPE)
        
        lineno = 0
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            lineno += 1
            self.read_gdsinfo_line(lineno, line.decode().rstrip())
        
def print_call_tree(gdsfile: GDSIIFile, cell: Celldef, indent:int=0, depth:int = -1):
    if depth == 0:
        return
    print(f"{'  '*indent}{cell.cellname()}")
    for child in gdsfile.cells_for_names(cell.childcells()):
        print_call_tree(gdsfile, child, indent+1, depth-1)
def print_layer_datatype(gdsfile: GDSIIFile):
    for layno in gdsfile.get_layer():
        for datatype in gdsfile.get_datatype(layno):
            print(f"ldt: {layno}:{datatype}")
#main

async def main():
    print(f"Testing {__file__}")
    
    gdsfile1: GDSIIFile = GDSIIFile(Path("/proot/hasn/0101/workareas-sos/camelot/hasn0101.gds"))
    print(f"created GDSInfoParser for {gdsfile1.path_to_gdsii()}")
    gdsinfoparser1: GDSInfoParser = GDSInfoParser(gdsfile1)   
    print(f"created gdsinfoparser")    

    
    gdsfile2: GDSIIFile = GDSIIFile(Path("/proot/hasn/0102/workareas-sos/camelot/hasn0102.gds"))
    print(f"created GDSInfoParser for {gdsfile2.path_to_gdsii()}")
    gdsinfoparser2: GDSInfoParser = GDSInfoParser(gdsfile2)   
    print(f"created gdsinfoparser")    
    beg = perf_counter()
    await asyncio.gather(gdsinfoparser1.read_gdsinfo_async(), gdsinfoparser2.read_gdsinfo_async())
    print(f"runtime {perf_counter() - beg}")
    print(f"topcells in {gdsfile1.path_to_gdsii()}: {show_listed_names(gdsfile1.all_topcell_names())}")
    for topcell in gdsfile1.all_topcell_names():
        print(f"Call tree for topcell '{topcell}'")
        print_call_tree(gdsfile1, gdsfile1.cell_for_name(topcell), indent = 1, depth=2)        
        print("-----\n\n")
    #print("undefined cells:\n  ",show_listed_names(gdsfile1.all_undefined_cell_names()))
    print(f"topcells in {gdsfile2.path_to_gdsii()}: {show_listed_names(gdsfile2.all_topcell_names())}")
    for topcell in gdsfile2.all_topcell_names():
        print(f"Call tree for topcell '{topcell}'")
        print_call_tree(gdsfile2, gdsfile2.cell_for_name(topcell), indent = 1, depth=2)        
        print("-----\n\n")
    #print("undefined cells:\n  ",show_listed_names(gdsfile2.all_undefined_cell_names()))
    print_layer_datatype(gdsfile2)

    #gdsfile = GDSIIFile("test.gds")
    #c1 = gdsfile.define_cell("child1")
    #c2 = gdsfile.define_cell("child2")
    #c3 = gdsfile.define_cell("child3")
    #c4 = gdsfile.define_cell("child4")
    #c1.add_call(c2.cellname())
    #c1.add_call(c4.cellname())
    #c1.add_call("nondefined5")
    #c2.add_call(c3.cellname())
    #print(c1)
    #print(c2)
    #print(c3)
    #print(f"Is {c1.cellname()} {c1.is_topcell()=}")
    #print(f"all topcells {show_listed_names(gdsfile.all_topcell_names())}")
    #for c in gdsfile.cells_for_names(gdsfile.all_topcell_names()):
    #    print(f"  {c}")
    #print(f"all leafcells {show_listed_names(gdsfile.all_leafcell_names())}")
    #for c in gdsfile.cells_for_names(gdsfile.all_leafcell_names()):
    #    print(f"  {c}")
    #print(f"topcell name of file '{gdsfile.topcell()}'")
    #print(f"undefined cells: {show_listed_names(gdsfile.all_undefined_cell_names())}")
    
    #print("All Cells:")
    #for c in gdsfile.all_cells():
    #    print(f"  {c}")
    #try:
    #    errCell = GDSIIFile.define_cell("child1")
    #    print(f"Error: c3 was accepted with cellname '{errCell.cellname()}'")
    #except Exception as e:
    #    pass
#    
    gdsinfotext = """\
Celldef: Leaf1
Celldef: Leaf2
Celldef: Sub1
Cellref: Sub2
Cellref: Leaf1
Cellref: Leaf2
Celldef: Sub2
Cellref: Undefined1
Cellref: Undefined2
Celldef: Top1
Cellref: Leaf1
Cellref: Sub1
Layer: 10 Datatype: 40
Layer: 30 Datatype: 0
"""
#    gdsinfotextfail = """\
#Cellref: fail
#Celldef: Leaf1
#Celldef: Leaf2
#Celldef: Sub1
#Cellref: Sub2
#Cellref: Leaf1
#Cellref: Leaf2
#Celldef: Sub2
#Cellref: Undefined1
#Cellref: Undefined2
#Celldef: Top1
#Cellref: Leaf1
#Cellref: Sub1
#Layer: 10 Datatype: 40
#Layer: 30 Datatype: 0
#"""
    if False:
        gdsfile2 = GDSIIFile("test2.gds")
#    gdsfile3 = GDSIIFile("test2.gds")
#    beg = perf_counter()
        gdsfile2.read_gdsinfo(gdsinfotext)
        for topcell in gdsfile2.all_topcell_names():
            print(f"Call tree for topcell {topcell}")
            print_call_tree(gdsfile, gdsfile2.cell_for_name(topcell))        
            print("-----\n\n")
#    gdsfile3.read_gdsinfo(gdsinfotext)
#    print(f"sync time: {perf_counter()-beg}")
#    
#    gdsfile4 = GDSIIFile("test2.gds")
#    gdsfile5 = GDSIIFile("test2.gds")
#    beg = perf_counter()
#    asyncio.gather(gdsfile4.async_read_gdsinfo(gdsinfotext), gdsfile5.async_read_gdsinfo(gdsinfotext), return_exceptions=True)
 #   print(f"async time: {perf_counter()-beg}")
#    
#    #print(f"Topcells '{show_listed_names(gdsfile2.all_topcell_names())}'")
 #   #print(f"All cells:")
 #   #for c in gdsfile2.all_cells():
 #   #    print(c)
        
    #print_call_tree(gdsfile2, gdsfile2.cell_for_name("Top1"))
    #print_layer_datatype(gdsfile2)
    #print(show_listed_names(gdsfile2.all_undefined_cell_names()))
    
    
    
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"Error: {e}")
    
