#!/tools/pdtooling/packages/VirtPythonEnv/pkg_synopsys/bin/python3
from collections import defaultdict
from typing import Any, Protocol, Callable, Tuple
from dataclasses import dataclass
import os
import re
from pathlib import Path
import asyncio
from time import perf_counter

@dataclass
class LayerPurposePair:
    layer:str = ""
    purpose:str = ""

    def __str__(self):
        return f"{self.layer}/{self.purpose}"

@dataclass
class GDSLayer:
    layerno: int = -1
    datatype: int = -1

    def __str__(self):
        return f"{self.layerno}:{self.datatype}"

class Layertable:
    def __init__(self, filename):
        self._layertable_name = filename
        self._layername = {}
        self._layerno   = {} # reverse mapping to layername

    def path_to_layertable(self):
        return self._layertable_name
    
    def add_layer(self, layername, purpose, layerno, datatype):
        # make layerno and datatype integers
        layerno = int(layerno)
        datatype = int (datatype)
        if not layername in self._layername:
            self._layername[layername] = {}
        purposedict = self._layername[layername]
        purposedict[purpose] = GDSLayer(layerno, datatype)

        if not layerno in self._layerno:
            self._layerno[layerno] = {}
        datatypedict = self._layerno[layerno]
        datatypedict[datatype] = LayerPurposePair(layername, purpose)

    def layerno_datatype_for(self, layername_or_lpp, purpose = None):
        if isinstance(layername_or_lpp, LayerPurposePair):
            return self._layername[layername_or_lpp.layer][layername_or_lpp.purpose]
        if purpose is None:
            raise KeyError(f"Missing purpose for {layername_or_lpp}")
        return self._layername[layername_or_lpp][purpose]

    def layername_purpose_for(self, layerno_or_gdspair, datatype = None):
        if isinstance(layerno_or_gdspair, GDSLayer):
            return self._layerno[layerno_or_gdspair.layerno][layerno_or_gdspair.datatype]
        if datatype is None:
            raise KeyError(f"Missing datatype for {layername_or_gdspair}")
        return self._layerno[layerno_or_gdspair][datatype]

    def layerno(self):
        return list(self._layerno.keys())
    def layername(self):
        return list(self._layername.keys())
    def datatype(self, layerno):
        return self._layerno[layerno].keys()
    def purpose(self,layername):
        return list(self._layername[layername].keys())

    def all_layerno_datatypes(self):
        return [ GDSLayer(ln, dt) for ln, dtl in self._layerno.items() for dt in dtl.keys()]
    def all_layername_purposes(self):
        return [ LayerPurposePair(ln,prp) for ln, prpl in self._layername.items() for prp in prpl.keys()]

    def __str__(self):
        ret_string = f"# {self._layertable_name}\n"
        for l in self._layername.keys():
            dt4l = self._layername[l]
            for dt in dt4l.keys():
                gdsno = dt4l[dt]
                ret_string += f"{l} {dt} {gdsno.layerno}  {gdsno.datatype}\n"
        return ret_string

class LayertableParser:
    def __init__(self, layertable):
        self._layertable = layertable
        self._emptyline=re.compile(r"^\s*$")
        self._layermapping= re.compile(r"\s*([^\s]+)\s+([^\s]+)\s+(\d+)\s+(\d+)")

    def read_line(self, line, lineno):
        line = line.split("#")[0].strip()
        if m:=self._emptyline.match(line):
            pass
        elif m:=self._layermapping.match(line):
            self._layertable.add_layer(m.group(1),m.group(2),int(m.group(3)),int(m.group(4)))
        else:
            raise Exception("Syntax error in {self.path_to_layertable()} line {lineno}")

    def read_lines(self, lines):
        for n, line in enumerate(lines.split("\n")):
            print(f"read {n}: {line}")
            self.read_line(line, n)

    def read_file(self):
        with open(self._layertable.path_to_layertable(), "r") as ltbl_handle:
            lineno = 0
            while line:=ltbl_handle.readline():
                lineno += 1
                self.read_line(line, lineno)

    async def read_file_async(self):
        with open(self._layertable.path_to_layertable(), "r") as ltbl_handle:
            lineno = 0
            while line:=ltbl_handle.readline():
                lineno += 1
                self.read_line(line, lineno)

        
def main():
    ltbl = Layertable("/proot/synopsys/pdkNew/release/release_250519/mnsc05prim/mnsc05prim.layermap")

    parser = LayertableParser(ltbl)

    if False:
        parser.read_lines("""
#Layer Name     Layer Purpose  Layer Stream Number  Datatype Stream Number

boundary       drawing        0                    0              
bpl            drawing        0                    3              
zero           drawing        0                    4              
physname       label          0                    50             
outline        label          0                    51             
well           drawing        1                    0              
dwell          drawing        1                    1              
hallwell       drawing        1                    2              
pn             drawing        2                    0              
fdn            drawing        3                    0              
pwell          drawing        3                    1              
pgi            drawing        3                    2              
phvwell        drawing        4                    0              
BSD            drawing        4                    1              
# subreg         drawing        4                    20             
subregicv      drawing        4                    21             
lowvoltage     drawing        4                    22             
""")
    else:
        parser.read_file()

    print(ltbl)
    try:
        print(ltbl.layername_purpose_for(56, 0))
    except KeyError as e:
        print("Error:",e)
    try:
        print(ltbl.layerno_datatype_for("subregicv", "drawing"))
    except Exception as e:
        print("Error:",e)
    try:
        print(ltbl._layerno.keys())
    except Exception as e:
        print("Error:",e)
    if False:
        for ln in ltbl.layerno():
            print(f"{ln}:")
            for dt in ltbl.datatype(ln):
                print(f"  {dt}: {ltbl.layername_purpose_for(ln, dt)}")
    else:
        if False:
            for lpp in ltbl.all_layername_purposes():
                print(f"{ltbl.layerno_datatype_for(lpp)}")
        else:
            for gdspair in ltbl.all_layerno_datatypes():
                print(f"{ltbl.layername_purpose_for(gdspair)}")
            


if __name__ == "__main__":
    main()
