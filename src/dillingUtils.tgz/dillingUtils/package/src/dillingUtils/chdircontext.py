from contextlib import contextmanager
import os

@contextmanager
def curdirctxt():
    curdir = os.getcwd()
    try: yield
    finally:
        os.chdir(curdir)

@contextmanager
def chdirctxt(path, create=False):
    curdir = os.getcwd()
    try:
        if create:
            os.makedirs(path, exist_ok=True)
        os.chdir(path)
        yield
    finally:
        os.chdir(curdir)

