from contextlib import contextmanager
import os

@contextmanager
def curdirctxt():
    curdir = os.getcwd()
    try: yield
    finally os.chdir(curdir)

@contextmanager
def chdirctxt(path):
    curdir = os.getcwd()
    try:
        os.chdir(path)
        yield
    finally:
        os.chdir(curdir)

