#!/tools/pdtooling/packages/VirtPythonEnv/pkg_synopsys/bin/python3
import projectinfo
import workareas

try:
    print(f"{projectinfo.cmd=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"{projectinfo.current_version=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"{projectinfo.dataorg=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"{projectinfo.dataorg_src=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"{projectinfo.project=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"{projectinfo.version=}")
    print(f"{projectinfo.projects=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"{projectinfo.technology=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"{projectinfo.variant=}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"Project: {projectinfo.project} Version: {projectinfo.version}")
except RuntimeError as re:
    print(f"RuntimeError: {re}")
except Exception as e:
    print(e)

try:
    print(f"workareas-sos {workareas.generateWorkareasName()=}")
    print(f"workareas-sos {workareas.generateWorkareasName('workareas-cd')=}")
    print(f"workareas-sos {workareas.generateWorkareasName('workareas-sos')=}")
except Exception as e:
    print(e)
    
try:
    print(f"guessed workarea {workareas.guessWorkdirName()=}")
except Exception as e:
    print(e)
    
try:
    print(f"guessed workarea {workareas.guessWorkdirName('camelot')=}")
except Exception as e:
    print(e)
