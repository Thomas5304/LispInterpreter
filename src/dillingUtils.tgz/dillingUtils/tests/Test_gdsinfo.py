#!/tools/pdtooling/packages/VirtPythonEnv/pkg_synopsys/bin/python3
from collections import defaultdict
from typing import Any, Protocol, Callable, Tuple
import os
import sys
import re
from pathlib import Path
import asyncio
import time

import tempfile
import unittest

# Pfad zum src-Ordner relativ zur Testdatei
src_dir = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(src_dir))

import gdsinfo


class Test_set_gdsinfo_path(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def touch(self, path: Path, mtime: float):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("x")
        # set modification time explizit
        os.utime(path, (mtime, mtime))

    def test_non_existing_file(self):
        filename = self.dir / "not_existing_file"
        with self.assertRaises(FileExistsError):
            gdsinfo.set_gdsinfo_path(filename)

    def test_existing_file_not_executable(self):
        filename = self.dir / "existing_file"
        now = time.time()
        self.touch(filename, now)
        with self.assertRaises(PermissionError):
            gdsinfo.set_gdsinfo_path(filename)
            
    def test_existing_file_executable(self):
        filename = self.dir / "existing_file"
        now = time.time()
        self.touch(filename, now)
        filename.chmod(0o755)
        gdsinfo.set_gdsinfo_path(filename)

    def test_show_listed_names(self):
        names = ["cell1", "cell2", "cell3", "last"]
        self.assertEqual("cell1, cell2, cell3, last", gdsinfo.show_listed_names(names))
        self.assertEqual("-None-", gdsinfo.show_listed_names([]))
        self.assertEqual("-None-", gdsinfo.show_listed_names(None))
        self.assertEqual("cell1", gdsinfo.show_listed_names(("cell1",)))

def main():
    unittest.main()

if __name__ == "__main__":
    main()
