#!/tools/pdtooling/packages/VirtPythonEnv/pkg_synopsys/bin/python3

import dillingUtils
import asyncio
from argparse import ArgumentParser, Action, ArgumentTypeError

def icvlpp(lpp: dillingUtils.LayerPurposePair):
    return f"{lpp.layer}_{lpp.purpose}"

async def main():
    parser = ArgumentParser()

    parser.add_argument("gdsfile1",
                        action="store")

    parser.add_argument("topcell1",
                        nargs="?",
                        action="store")

    parser.add_argument("gdsfile2",
                        action="store")

    parser.add_argument("topcell2",
                        nargs="?",
                        action="store")

    parser.add_argument("--layermap",
                        dest="layermap",
                        default=None,
                        action="store")

    args = parser.parse_args()

    gdsiifile1 = dillingUtils.GDSIIFile(args.gdsfile1)

    gdsiiparser1 = dillingUtils.GDSInfoParser(gdsiifile1)

    gdsiifile2 = dillingUtils.GDSIIFile(args.gdsfile2)

    gdsiiparser2 = dillingUtils.GDSInfoParser(gdsiifile2)

    layertable = dillingUtils.Layertable(args.layermap)
    tasks = [asyncio.create_task(gdsiiparser1.read_gdsinfo_async()), asyncio.create_task(gdsiiparser2.read_gdsinfo_async())]
    if args.layermap is not None:
        layertableparser = dillingUtils.LayertableParser(layertable)
        tasks.append(asyncio.create_task(layertableparser.read_file_async()))

    await asyncio.gather(*tasks)

    lnodt1=set(gdsiifile1.get_layer_datatypes())
    lnodt2=set(gdsiifile2.get_layer_datatypes())

    if (lnodt1 < lnodt2):
        print(f"missing layer in 1st {gdsiifile1.path_to_gdsii()} {lnodt2-lnodt1}")
    elif (lnodt1 > lnodt2):
        print(f"missing lnodt in 2nd {gdsiifile2.path_to_gdsii()} {lnodt1-lnodt2}")
    
    for lnodt in sorted(lnodt1|lnodt2):
        print(f"{lnodt[0]}:{lnodt[1]} -> {layertable.layername_purpose_for(lnodt[0], lnodt[1])}")

    topcells1 = gdsiifile1.all_topcell_names()
    if len(topcells1) == 1:
        print(f"The topcell in layout 1 is '{topcells1[0]}'")
    else:
        print(f"The topcells in layout 1 are: '", "', '".join(topcells1),"'")

    topcells2 = gdsiifile2.all_topcell_names()
    if len(topcells2) == 1:
        print(f"The topcell in layout 2 is '{topcells2[0]}'")
    else:
        print(f"The topcells in layout 2 are: '", "', '".join(topcells2),"'")

    if args.topcell1 is None:
        args.topcell1 = gdsiifile1.topcell()
        print(f"topcell for layout 1 is guessed as {args.topcell1}")
    if args.topcell2 is None:
        args.topcell2 = gdsiifile2.topcell()
        print(f"topcell for layout 2 is guessed as {args.topcell2}")

    print(f"icvcomp {args.topcell1} vs {args.topcell2}")

    with dillingUtils.chdirctxt("icvcomp_testdir", True):
        with open("control.rs", "w") as control:
            for lnodt in sorted(lnodt1|lnodt2):
                print(f"{icvlpp(layertable.layername_purpose_for(lnodt[0], lnodt[1]))} = assign({{{{{{{lnodt[0]}, {lnodt[1]} }}}}}});", file = control)
            
    
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as e:
        print(f"Error: {e}")
